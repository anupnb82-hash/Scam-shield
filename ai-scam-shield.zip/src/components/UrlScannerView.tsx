import React, { useState } from 'react';
import { 
  Globe, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  ExternalLink, 
  Lock, 
  Unlock, 
  Layers, 
  ArrowRight,
  Sparkles,
  Link2
} from 'lucide-react';
import { AnalyzeUrlResponse, ActiveTab } from '../types';

interface UrlScannerViewProps {
  onNavigate: (tab: ActiveTab, prefillData?: any) => void;
}

export const UrlScannerView: React.FC<UrlScannerViewProps> = ({ onNavigate }) => {
  const [urlInput, setUrlInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<AnalyzeUrlResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const testUrls = [
    { label: 'Fake Bank XYZ', url: 'https://sbi-banking-auth-update.xyz/verify' },
    { label: 'Subdomain Phishing', url: 'http://login.secure.bank.account.verification.top/update' },
    { label: 'Direct IP Lure', url: 'http://192.168.1.55/update-credentials' },
    { label: 'Brand Spoof Buzz', url: 'https://netflix-subscription-renew.buzz/billing' },
    { label: 'Safe Official Link', url: 'https://github.com/security' }
  ];

  const handleScan = async (targetUrl?: string) => {
    const urlToScan = targetUrl || urlInput;
    if (!urlToScan.trim()) {
      setError('Please enter or select a URL to scan.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/analyze-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlToScan.trim() })
      });

      if (!response.ok) {
        throw new Error('Failed to analyze URL');
      }

      const data: AnalyzeUrlResponse = await response.json();
      setResult(data);
    } catch (err) {
      console.error('URL scan error:', err);
      setError('Failed to scan URL. Please verify server connection.');
    } finally {
      setLoading(false);
    }
  };

  const getRiskTheme = (level: string) => {
    switch (level) {
      case 'HIGH':
        return {
          border: 'border-red-500/50',
          bg: 'bg-red-950/20',
          text: 'text-red-400',
          icon: <ShieldAlert className="w-5 h-5 text-red-400" />
        };
      case 'MEDIUM':
        return {
          border: 'border-amber-500/50',
          bg: 'bg-amber-950/20',
          text: 'text-amber-400',
          icon: <AlertTriangle className="w-5 h-5 text-amber-400" />
        };
      default:
        return {
          border: 'border-emerald-500/50',
          bg: 'bg-emerald-950/20',
          text: 'text-emerald-400',
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />
        };
    }
  };

  const isHttps = (urlInput || '').toLowerCase().startsWith('https://');

  return (
    <div className="space-y-6 animate-fadeIn" id="url-scanner-section">
      <div className="bg-slate-900/40 border border-white/10 rounded-[2.5rem] p-6 sm:p-8 backdrop-blur-2xl shadow-2xl relative">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2.5">
              <Globe className="w-6 h-6 text-blue-400" />
              Secure URL Scanner
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Enter a link to inspect for domain spoofing, suspicious TLDs, excessive nested subdomains, and HTTP insecurity.
            </p>
          </div>
          <span className="px-3 py-1 bg-blue-500/20 text-blue-400 text-[10px] font-bold rounded-full border border-blue-500/20 uppercase tracking-wider self-start sm:self-auto">
            DNS & TLD Engine
          </span>
        </div>

        {/* Demo Link Chips */}
        <div className="mb-5">
          <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-widest mb-2.5">
            Sample Links to Test:
          </p>
          <div className="flex flex-wrap gap-2">
            {testUrls.map((item, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setUrlInput(item.url);
                  handleScan(item.url);
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Link2 className="w-3 h-3 text-blue-400" />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* URL Input */}
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              {isHttps ? <Lock className="w-4 h-4 text-emerald-400" /> : <Unlock className="w-4 h-4 text-amber-400" />}
            </div>
            <input
              type="text"
              id="url-input"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="https://example-banking.com/verify"
              className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-black/40 border border-white/10 text-sm font-mono text-white placeholder:text-slate-600 focus:ring-2 focus:ring-blue-500/50 outline-none backdrop-blur-md"
              onKeyDown={(e) => e.key === 'Enter' && handleScan()}
            />
          </div>

          <button
            onClick={() => handleScan()}
            disabled={loading}
            className="py-3.5 px-6 rounded-2xl font-black text-sm uppercase tracking-wider bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white shadow-xl shadow-blue-900/40 transition-all disabled:opacity-50 cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
            id="btn-check-link"
          >
            {loading ? (
              <>
                <Sparkles className="w-4 h-4 animate-spin text-white" />
                <span>Scanning Link...</span>
              </>
            ) : (
              <span>Check Link</span>
            )}
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Results Panel */}
        {result && (
          <div 
            id="url-result" 
            className={`mt-6 p-6 sm:p-7 rounded-[2rem] border backdrop-blur-xl space-y-4 animate-fadeIn ${
              result.risk_level === 'HIGH' ? 'bg-rose-500/10 border-rose-500/30' :
              result.risk_level === 'MEDIUM' ? 'bg-amber-500/10 border-amber-500/30' :
              'bg-emerald-500/10 border-emerald-500/30'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                  {getRiskTheme(result.risk_level).icon}
                </div>
                <div>
                  <h3 className="text-xl font-black text-white tracking-tight">
                    URL Risk: {result.risk_score}/100
                  </h3>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase ${
                      result.risk_level === 'HIGH' ? 'bg-rose-500 text-white shadow-md shadow-rose-500/30' :
                      result.risk_level === 'MEDIUM' ? 'bg-amber-500 text-white shadow-md shadow-amber-500/30' :
                      'bg-emerald-500 text-white shadow-md shadow-emerald-500/30'
                    }`}>
                      {result.risk_level} RISK LEVEL
                    </span>
                    <span className="text-xs text-slate-400 truncate max-w-xs font-mono">
                      {urlInput}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {result.risk_score > 40 && (
                  <button
                    onClick={() => onNavigate('report', { 
                      description: `Phishing URL identified: ${urlInput}`,
                      category: 'Phishing'
                    })}
                    className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-500/30 transition-colors cursor-pointer"
                  >
                    Report URL to Community
                  </button>
                )}
              </div>
            </div>

            {/* Threat factors */}
            <div>
              <h4 className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-300 mb-2">
                Domain Threat Analysis Findings:
              </h4>
              <div className="space-y-2">
                {result.threats.map((reason, idx) => (
                  <div 
                    key={idx} 
                    className="text-xs sm:text-sm text-slate-200 bg-black/30 p-3 rounded-xl border border-white/5 flex items-start gap-2.5"
                  >
                    <span className="text-amber-400 flex-shrink-0 mt-0.5">•</span>
                    <span>{reason}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Guidance */}
            <div className="p-4 rounded-xl bg-black/40 border border-white/10 text-xs text-slate-300 space-y-1">
              <span className="font-bold text-slate-200 block uppercase tracking-wider text-[10px]">Cybersecurity Advice:</span>
              <p className="leading-relaxed">
                {result.risk_level === 'HIGH' 
                  ? 'Never enter credentials, passwords, or one-time passwords (OTPs) on this link. Close the browser tab and verify official web addresses using a trusted search engine.'
                  : result.risk_level === 'MEDIUM'
                  ? 'Examine the destination domain carefully before taking any action or logging in.'
                  : 'No high-risk top-level domain spoofing or excessive subdomain patterns were identified. Continue exercising normal web safety.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
