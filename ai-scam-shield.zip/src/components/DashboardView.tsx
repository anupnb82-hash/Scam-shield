import React, { useEffect, useState } from 'react';
import { 
  ShieldAlert, 
  Activity, 
  ShieldCheck, 
  RefreshCw, 
  AlertTriangle, 
  Clock, 
  UserX, 
  ArrowRight,
  TrendingUp,
  Radio
} from 'lucide-react';
import { DashboardData, ThreatReport, ActiveTab } from '../types';

interface DashboardViewProps {
  onNavigate: (tab: ActiveTab, prefillData?: any) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const [data, setData] = useState<DashboardData>({
    total_scans: 1284,
    high_risk: 452,
    recent_reports: []
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboardData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/dashboard');
      if (!res.ok) throw new Error('Network response was not ok');
      const json: DashboardData = await res.json();
      setData(json);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
      setError('Could not connect to threat intelligence feed. Using cached data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const getSeverityBadge = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'high':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-red-500/10 text-red-400 border border-red-500/30">
            HIGH SEVERITY
          </span>
        );
      case 'medium':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30">
            MEDIUM SEVERITY
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            LOW SEVERITY
          </span>
        );
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn" id="dashboard-view">
      {/* Stat Cards Grid (Frosted Glass) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5" id="dashboard-grid">
        {/* Total Scans */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md relative overflow-hidden group hover:border-white/20 transition-all shadow-xl">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <Activity className="w-16 h-16 text-blue-400" />
          </div>
          <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-widest mb-1 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-blue-400" />
            Total Scans
          </p>
          <div className="flex items-baseline gap-3">
            <h3 className="text-3xl sm:text-4xl font-black text-white tracking-tight" id="stat-scans">
              {data.total_scans.toLocaleString()}
            </h3>
            <div className="text-[10px] sm:text-xs text-emerald-400 font-bold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>↑ 12%</span>
              <span className="text-slate-500 font-normal hidden sm:inline">vs last week</span>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-2">Aggregated messages & verified URLs</p>
        </div>

        {/* High Risk Detected */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md relative overflow-hidden group hover:border-rose-500/30 transition-all shadow-xl">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <ShieldAlert className="w-16 h-16 text-rose-500" />
          </div>
          <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-widest mb-1 flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            High Risk Intercepted
          </p>
          <div className="flex items-baseline gap-3">
            <h3 className="text-3xl sm:text-4xl font-black text-rose-500 tracking-tight" id="stat-high">
              {data.high_risk.toLocaleString()}
            </h3>
            <div className="text-[10px] sm:text-xs text-rose-400 font-bold flex items-center gap-1">
              <span>↑ 4%</span>
              <span className="text-slate-500 font-normal">active threats</span>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-2">Phishing lures, UPI traps & fake job networks</p>
        </div>

        {/* Safety Score */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md relative overflow-hidden group hover:border-emerald-500/30 transition-all shadow-xl">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <ShieldCheck className="w-16 h-16 text-emerald-400" />
          </div>
          <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-widest mb-1 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Collective Safety Score
          </p>
          <div className="flex items-baseline gap-3">
            <h3 className="text-3xl sm:text-4xl font-black text-emerald-400 tracking-tight" id="stat-safety">
              98.2%
            </h3>
            <span className="text-[10px] sm:text-xs font-bold text-emerald-400 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
              Optimal Defense
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-2">Heuristic AI pattern accuracy benchmark</p>
        </div>
      </div>

      {/* Quick Launchpad Banner (Frosted Glass) */}
      <div className="bg-slate-900/40 border border-white/10 rounded-[2rem] p-6 sm:p-7 backdrop-blur-2xl shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h4 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
            <Radio className="w-4 h-4 text-blue-400 animate-pulse" />
            Active Scam Interception Engine
          </h4>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Received a suspicious text, WhatsApp job offer, or lottery alert? Test it through our multi-pattern AI detector.
          </p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={() => onNavigate('analyzer')}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs sm:text-sm font-bold tracking-wide shadow-lg shadow-blue-900/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer uppercase"
            id="btn-quick-analyze"
          >
            <span>Scan Message</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => onNavigate('url-scanner')}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs sm:text-sm font-bold tracking-wide border border-white/10 hover:border-white/20 transition-all cursor-pointer uppercase"
            id="btn-quick-url"
          >
            <span>Check URL</span>
          </button>
        </div>
      </div>

      {/* Recent Global Threats Section (Frosted Matrix) */}
      <div className="bg-slate-900/40 border border-white/10 rounded-[2rem] p-6 sm:p-8 backdrop-blur-2xl shadow-2xl relative" id="recent-threats-card">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg sm:text-xl font-black uppercase tracking-widest text-blue-400">
                Global Threat Matrix
              </h3>
              <span className="text-[10px] font-bold bg-blue-500/10 text-blue-400 px-2.5 py-1 rounded-md border border-blue-500/20">
                Live Feed
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Crowdsourced and authenticated scam alerts reported across WhatsApp, SMS, and Banking gateways
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchDashboardData}
              disabled={loading}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold border border-white/10 transition-colors disabled:opacity-50 cursor-pointer"
              title="Refresh intelligence feed"
              id="btn-refresh-feed"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-blue-400' : ''}`} />
              <span>Sync Feed</span>
            </button>

            <button
              onClick={() => onNavigate('report')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold border border-rose-500/30 transition-colors cursor-pointer"
              id="btn-report-feed-action"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>Submit Report</span>
            </button>
          </div>
        </div>

        {error && (
          <div className="my-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Reports Matrix List */}
        <div className="space-y-3 mt-5" id="recent-reports-list">
          {loading && data.recent_reports.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-sm">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto text-blue-400 mb-2" />
              Loading real-time threat intelligence...
            </div>
          ) : data.recent_reports.length === 0 ? (
            <div className="py-10 text-center text-slate-500 text-sm">
              No recent community reports recorded yet. Be the first to submit threat intelligence.
            </div>
          ) : (
            data.recent_reports.map((report: ThreatReport) => {
              const barColor = 
                report.severity?.toLowerCase() === 'high' ? 'bg-rose-500' :
                report.severity?.toLowerCase() === 'medium' ? 'bg-amber-500' : 'bg-emerald-500';

              return (
                <div 
                  key={report.id || report.timestamp} 
                  className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-white/5 border border-white/5 hover:border-white/15 hover:bg-white/[0.08] transition-all backdrop-blur-md group"
                >
                  <div className="flex items-start gap-3.5 flex-1">
                    {/* Glowing vertical bar indicator */}
                    <div className={`w-1.5 min-h-[3rem] ${barColor} rounded-full flex-shrink-0 mt-0.5 shadow-sm`} />
                    <div className="space-y-1 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-bold text-sm text-white">
                          {report.category}
                        </span>
                        {getSeverityBadge(report.severity)}
                        <span className="flex items-center gap-1 text-slate-400 text-xs">
                          <Clock className="w-3 h-3 text-slate-500" />
                          {report.timestamp}
                        </span>
                      </div>

                      <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                        {report.description}
                      </p>

                      <div className="flex items-center gap-2 text-xs text-slate-400 pt-0.5">
                        <UserX className="w-3.5 h-3.5 text-slate-500" />
                        <span>Identifier: <code className="text-slate-300 font-mono bg-black/40 px-1.5 py-0.5 rounded border border-white/10 text-[11px]">{report.sender}</code></span>
                      </div>
                    </div>
                  </div>

                  <div className="sm:self-center w-full sm:w-auto flex justify-end">
                    <button
                      onClick={() => onNavigate('analyzer', { text: report.description })}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white/5 text-slate-300 text-xs font-bold hover:text-white hover:bg-blue-600/30 hover:border-blue-500/40 border border-white/10 transition-all cursor-pointer whitespace-nowrap uppercase tracking-wider"
                      title="Analyze this exact content in the scam detector"
                    >
                      <span>Analyze Pattern</span>
                      <ArrowRight className="w-3 h-3 text-blue-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
