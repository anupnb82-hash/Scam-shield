import React, { useState } from 'react';
import { 
  Flag, 
  Send, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  User, 
  FileText, 
  Tag, 
  Sparkles,
  ArrowLeft
} from 'lucide-react';
import { ActiveTab } from '../types';

interface ReportViewProps {
  initialData?: {
    description?: string;
    category?: string;
    sender?: string;
  };
  onNavigate: (tab: ActiveTab) => void;
}

export const ReportView: React.FC<ReportViewProps> = ({ initialData, onNavigate }) => {
  const [sender, setSender] = useState<string>(initialData?.sender || '');
  const [category, setCategory] = useState<string>(initialData?.category || 'Phishing');
  const [severity, setSeverity] = useState<'High' | 'Medium' | 'Low'>('High');
  const [description, setDescription] = useState<string>(initialData?.description || '');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sender.trim() || !description.trim()) {
      setErrorMessage('Please provide both the sender identifier and description.');
      return;
    }

    setSubmitting(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender: sender.trim(),
          category,
          severity,
          description: description.trim()
        })
      });

      if (!response.ok) {
        throw new Error('Server rejected report');
      }

      setSuccessMessage('Thank you for your contribution to collective security!');
      setTimeout(() => {
        onNavigate('dashboard');
      }, 1600);
    } catch (err) {
      console.error('Failed to submit report:', err);
      setErrorMessage('Failed to submit report. Please try again.');
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn" id="report-section">
      <div className="bg-slate-900/40 border border-white/10 rounded-[2.5rem] p-6 sm:p-8 max-w-3xl mx-auto backdrop-blur-2xl shadow-2xl relative">
        <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-white/10">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2.5">
              <Flag className="w-6 h-6 text-rose-400" />
              Report a Scam
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Crowdsource threat intelligence to warn others and bolster the automated heuristic firewall.
            </p>
          </div>

          <button
            onClick={() => onNavigate('dashboard')}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>
        </div>

        {successMessage ? (
          <div className="p-8 text-center space-y-4 rounded-3xl bg-emerald-500/10 border border-emerald-500/30 backdrop-blur-xl animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30 shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white">Report Logged Successfully</h3>
            <p className="text-sm text-slate-300 max-w-md mx-auto">
              {successMessage}
            </p>
            <p className="text-xs text-slate-500 font-mono">
              Redirecting you to the live intelligence dashboard...
            </p>
          </div>
        ) : (
          <form id="report-form" onSubmit={handleSubmit} className="space-y-5">
            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Sender Number / ID */}
            <div>
              <label htmlFor="rep-sender" className="block text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-300 mb-2 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-blue-400" />
                Sender Phone Number, Email, or Telegram ID
              </label>
              <input
                type="text"
                id="rep-sender"
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                placeholder="+91 98765 43210 or @ScamRecruiter_Bot"
                required
                className="w-full px-4 py-3.5 rounded-2xl bg-black/40 border border-white/10 text-sm font-mono text-white placeholder:text-slate-600 focus:ring-2 focus:ring-blue-500/50 outline-none backdrop-blur-md"
              />
            </div>

            {/* Category and Severity Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="rep-cat" className="block text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-300 mb-2 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-blue-400" />
                  Scam Category
                </label>
                <select
                  id="rep-cat"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-4 py-3.5 rounded-2xl bg-black/60 border border-white/10 text-sm text-white focus:ring-2 focus:ring-blue-500/50 outline-none backdrop-blur-md cursor-pointer"
                >
                  <option value="Phishing">Phishing / Bank Impersonation</option>
                  <option value="UPI Fraud">UPI Fraud / QR Code Request</option>
                  <option value="Job Scam">Job Scam / Telegram Work Task</option>
                  <option value="Investment Scam">Investment / Crypto Doubling</option>
                  <option value="Lottery Scam">Lottery / Gift Card Manipulation</option>
                  <option value="Electricity Disconnection">Utility / Bill Disconnection Fear</option>
                  <option value="Other Threat">Other Digital Fraud</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-300 mb-2 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                  Assessed Threat Severity
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['High', 'Medium', 'Low'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setSeverity(lvl)}
                      className={`py-3 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                        severity === lvl
                          ? lvl === 'High'
                            ? 'bg-rose-600/40 border-rose-500 text-white shadow-lg shadow-rose-600/20'
                            : lvl === 'Medium'
                            ? 'bg-amber-600/40 border-amber-500 text-white shadow-lg shadow-amber-600/20'
                            : 'bg-emerald-600/40 border-emerald-500 text-white shadow-lg shadow-emerald-600/20'
                          : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      {lvl.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Context description */}
            <div>
              <label htmlFor="rep-desc" className="block text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-300 mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-400" />
                Scam Context / Full Message Copy
              </label>
              <textarea
                id="rep-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Include details: what did they ask for? Was there a link, payment QR, or APK download link requested?"
                rows={4}
                required
                className="w-full p-4 rounded-2xl bg-black/40 border border-white/10 text-sm font-mono text-white placeholder:text-slate-600 focus:ring-2 focus:ring-blue-500/50 outline-none resize-none backdrop-blur-md leading-relaxed"
              />
            </div>

            {/* Submit button */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-4 sm:py-5 rounded-2xl font-black text-base sm:text-lg uppercase tracking-widest bg-gradient-to-r from-rose-600 via-rose-500 to-red-600 hover:from-rose-500 hover:to-red-500 text-white shadow-xl shadow-rose-900/40 hover:scale-[1.01] active:scale-[0.99] transition-transform disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
              id="btn-submit-report"
            >
              {submitting ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin text-white" />
                  <span>Submitting to Community Network...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 text-white" />
                  <span>Submit Intelligence Report</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
