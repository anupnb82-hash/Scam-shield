import React, { useState, useEffect } from 'react';
import { 
  Search, 
  AlertOctagon, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  Sparkles, 
  Zap, 
  Copy, 
  Check, 
  Flag, 
  ChevronRight,
  HelpCircle,
  BrainCircuit,
  Lock
} from 'lucide-react';
import { AnalyzeTextResponse, ActiveTab } from '../types';

interface AnalyzerViewProps {
  initialText?: string;
  onNavigate: (tab: ActiveTab, prefillData?: any) => void;
}

export const AnalyzerView: React.FC<AnalyzerViewProps> = ({ initialText, onNavigate }) => {
  const [inputText, setInputText] = useState<string>(initialText || '');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<AnalyzeTextResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [enableDeepAi, setEnableDeepAi] = useState<boolean>(true);

  useEffect(() => {
    if (initialText) {
      setInputText(initialText);
    }
  }, [initialText]);

  const fillDemo = (type: number) => {
    const demos: Record<number, string> = {
      1: "URGENT! Your SBI account will be blocked today. Complete KYC immediately using https://bit.ly/secure-bank-update",
      2: "Congratulations! You won ₹50,000 lottery. Pay ₹999 processing fee to claim your reward immediately.",
      3: "Your electricity connection will be disconnected tonight at 9:30 PM due to unpaid bill of ₹3,450. Immediately contact electricity officer at 9876543210 or scan UPI QR to avoid disruption.",
      4: "Part-time Work from home! Earn guaranteed salary of ₹4,000 daily with simple YouTube like tasks. Registration fee ₹500 refundable. Message Telegram @Global_Work_VIP now.",
      5: "Your order #82941 has been dispatched via BlueDart and is out for delivery today. OTP is required only upon physical handover by the courier."
    };

    if (demos[type]) {
      setInputText(demos[type]);
      setResult(null);
    }
  };

  const handleAnalyze = async () => {
    if (!inputText.trim()) {
      setError('Please enter or paste a message to analyze.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: inputText, deepAi: enableDeepAi })
      });

      if (!response.ok) {
        throw new Error(`Analysis server error: ${response.status}`);
      }

      const data: AnalyzeTextResponse = await response.json();
      setResult(data);
    } catch (err) {
      console.error('Scam analysis failed:', err);
      setError('Failed to complete AI analysis. Please verify your connection.');
    } finally {
      setLoading(false);
    }
  };

  const copyResults = () => {
    if (!result) return;
    const textToCopy = `[AI Scam Shield Report]\nRisk Level: ${result.risk_level} (${result.risk_score}/100)\nCategory: ${result.category}\nThreats: ${result.threats.join(', ')}\nRecommendation: ${result.recommendation}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getThemeConfig = (level: string) => {
    switch (level) {
      case 'HIGH':
        return {
          cardBg: 'bg-rose-500/10 border-rose-500/30',
          watermark: 'THREAT',
          watermarkColor: 'text-rose-500/20',
          circleBorder: 'border-rose-500',
          circleShadow: 'shadow-[0_0_30px_rgba(244,63,94,0.3)]',
          scoreColor: 'text-rose-500',
          labelColor: 'text-rose-400',
          pillBg: 'bg-rose-500 text-white',
          threatIcon: 'text-rose-500'
        };
      case 'MEDIUM':
        return {
          cardBg: 'bg-amber-500/10 border-amber-500/30',
          watermark: 'WARNING',
          watermarkColor: 'text-amber-500/20',
          circleBorder: 'border-amber-500',
          circleShadow: 'shadow-[0_0_30px_rgba(245,158,11,0.3)]',
          scoreColor: 'text-amber-500',
          labelColor: 'text-amber-400',
          pillBg: 'bg-amber-500 text-white',
          threatIcon: 'text-amber-500'
        };
      default:
        return {
          cardBg: 'bg-emerald-500/10 border-emerald-500/30',
          watermark: 'SECURE',
          watermarkColor: 'text-emerald-500/20',
          circleBorder: 'border-emerald-500',
          circleShadow: 'shadow-[0_0_30px_rgba(16,185,129,0.3)]',
          scoreColor: 'text-emerald-400',
          labelColor: 'text-emerald-300',
          pillBg: 'bg-emerald-500 text-white',
          threatIcon: 'text-emerald-400'
        };
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn" id="analyzer-section">
      {/* Frosted Glass Analyzer Card */}
      <div className="bg-slate-900/40 border border-white/10 rounded-[2.5rem] p-6 sm:p-8 backdrop-blur-2xl shadow-2xl relative">
        {/* Version Badge from Design */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2.5">
              <Search className="w-6 h-6 text-blue-400" />
              AI Message Analyzer
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              Paste suspicious SMS, Email content, or URLs for instant threat assessment.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="px-3 py-1 bg-blue-500/20 text-blue-400 text-[10px] font-bold rounded-full border border-blue-500/20 uppercase tracking-wider">
              AI v4.2 Stable
            </span>
            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10 hover:bg-white/10 transition-colors">
              <input
                type="checkbox"
                checked={enableDeepAi}
                onChange={(e) => setEnableDeepAi(e.target.checked)}
                className="rounded border-slate-700 text-blue-600 focus:ring-0 cursor-pointer"
              />
              <BrainCircuit className="w-3.5 h-3.5 text-blue-400" />
              <span>Deep Explainability</span>
            </label>
          </div>
        </div>

        {/* Demo Example Chips */}
        <div className="mb-4">
          <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-widest mb-2.5">
            Quick Test Examples (Click to simulate):
          </p>
          <div className="flex flex-wrap gap-2 demo-chips" id="demo-chips">
            <button
              onClick={() => fillDemo(1)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>🚨 Fake KYC Block</span>
            </button>
            <button
              onClick={() => fillDemo(2)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>🎁 Lottery Claim Fee</span>
            </button>
            <button
              onClick={() => fillDemo(3)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>⚡ Power Cutoff / UPI Pin</span>
            </button>
            <button
              onClick={() => fillDemo(4)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>💼 Telegram Job Scam</span>
            </button>
            <button
              onClick={() => fillDemo(5)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>📦 Legitimate Delivery (Safe)</span>
            </button>
          </div>
        </div>

        {/* Text Input Area (Frosted dark input from Design HTML) */}
        <div className="relative mb-5">
          <textarea
            id="analyze-input"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Paste suspicious SMS, Email content, or URLs for instant threat assessment..."
            className="w-full h-44 bg-black/40 border border-white/10 rounded-2xl p-5 sm:p-6 text-slate-200 placeholder-slate-600 focus:ring-2 focus:ring-blue-500/50 outline-none resize-none font-mono text-sm leading-relaxed backdrop-blur-md"
          />
          <div className="absolute bottom-4 right-4 flex gap-2">
            {inputText && (
              <button
                onClick={() => { setInputText(''); setResult(null); }}
                className="px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-[10px] font-bold text-slate-300 transition-colors cursor-pointer"
              >
                Clear
              </button>
            )}
            <button
              onClick={() => fillDemo(1)}
              className="px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-[10px] font-bold text-slate-300 transition-colors cursor-pointer"
            >
              Paste Demo
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertOctagon className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Action Button (from Design HTML) */}
        <button
          onClick={handleAnalyze}
          disabled={loading}
          className="w-full py-4 sm:py-5 bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 rounded-2xl font-black text-base sm:text-lg tracking-widest shadow-xl shadow-blue-900/40 hover:scale-[1.01] active:scale-[0.99] transition-transform uppercase text-white disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
          id="btn-run-inspection"
        >
          {loading ? (
            <>
              <Sparkles className="w-5 h-5 animate-spin text-white" />
              <span>Scanning message with AI Engine...</span>
            </>
          ) : (
            <>
              <Zap className="w-5 h-5 text-cyan-300" />
              <span>Run AI Inspection</span>
            </>
          )}
        </button>

        {/* Frosted Glass Results Display */}
        {result && (
          <div 
            id="analyze-result"
            className={`mt-8 border rounded-[2.5rem] p-6 sm:p-8 backdrop-blur-xl relative overflow-hidden transition-all animate-fadeIn ${getThemeConfig(result.risk_level).cardBg}`}
          >
            {/* Background Watermark from Design HTML */}
            <div className="absolute top-0 right-0 p-4 select-none pointer-events-none opacity-20 hidden sm:block">
              <span className={`text-7xl sm:text-8xl font-black ${getThemeConfig(result.risk_level).watermarkColor}`}>
                {getThemeConfig(result.risk_level).watermark}
              </span>
            </div>

            <div className="flex flex-col md:flex-row items-start md:items-center gap-6 sm:gap-8 z-10 relative">
              {/* Circular Risk Score Badge from Design HTML */}
              <div className="flex flex-col items-center justify-center gap-2 flex-shrink-0 mx-auto md:mx-0">
                <div className={`w-28 h-28 rounded-full border-[6px] ${getThemeConfig(result.risk_level).circleBorder} flex flex-col items-center justify-center bg-black/20 ${getThemeConfig(result.risk_level).circleShadow}`}>
                  <span className={`text-3xl font-black ${getThemeConfig(result.risk_level).scoreColor}`} id="res-score">
                    {result.risk_score}
                  </span>
                  <span className={`text-[10px] font-bold uppercase tracking-tighter ${getThemeConfig(result.risk_level).labelColor}`}>
                    Risk Score
                  </span>
                </div>
                <span className={`px-4 py-1 text-[10px] font-black rounded-full uppercase shadow-lg ${getThemeConfig(result.risk_level).pillBg}`}>
                  {result.risk_level} RISK
                </span>
              </div>

              {/* Analysis Content & Threats */}
              <div className="flex-1 space-y-4 w-full">
                <div>
                  <p className={`text-xs sm:text-sm font-bold uppercase tracking-widest ${getThemeConfig(result.risk_level).labelColor}`}>
                    Analysis Result
                  </p>
                  <h2 className="text-2xl sm:text-3xl font-black text-white" id="res-cat">
                    {result.category}
                  </h2>
                </div>

                {/* Threat Factors Grid */}
                <div>
                  <h5 className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-300 mb-2">
                    Detected Threat Signals & Red Flags:
                  </h5>
                  {result.threats.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2" id="res-threats">
                      {result.threats.map((threat, idx) => (
                        <div 
                          key={idx} 
                          className="flex items-center gap-2 text-xs sm:text-sm text-slate-200 bg-black/30 p-2.5 rounded-xl border border-white/5"
                        >
                          <span className={getThemeConfig(result.risk_level).threatIcon}>⚠️</span>
                          <span className="font-medium">{threat}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>No common malicious patterns, urgent deadlines, or known scam triggers identified.</span>
                    </div>
                  )}
                </div>

                {/* Deep AI Explainability */}
                {result.ai_explanation && (
                  <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-blue-400 uppercase tracking-wider">
                      <Sparkles className="w-4 h-4" />
                      <span>Psychological Manipulation Analysis</span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {result.ai_explanation}
                    </p>

                    {result.psychological_triggers && result.psychological_triggers.length > 0 && (
                      <div className="pt-2 border-t border-white/5">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                          Social Engineering Levers Deployed:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {result.psychological_triggers.map((trigger, i) => (
                            <span key={i} className="text-xs px-2.5 py-0.5 rounded-md bg-white/5 text-slate-200 border border-white/10 font-mono">
                              {trigger}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {result.verification_steps && result.verification_steps.length > 0 && (
                      <div className="pt-2 border-t border-white/5">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                          Recipient Verification Checklist:
                        </span>
                        <ul className="space-y-1">
                          {result.verification_steps.map((step, i) => (
                            <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                              <span className="text-cyan-400 font-bold">✓</span>
                              <span>{step}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                {/* Expert Recommendation (Design HTML Box) */}
                <div className="p-4 bg-black/40 rounded-xl border border-white/10">
                  <p className="text-[10px] text-slate-400 font-black uppercase mb-1 tracking-wider">
                    Expert Recommendation
                  </p>
                  <p className="text-xs sm:text-sm leading-relaxed text-slate-200" id="res-rec">
                    <span className={`font-bold ${getThemeConfig(result.risk_level).scoreColor}`}>
                      {result.risk_level === 'HIGH' ? 'DO NOT INTERACT. ' : result.risk_level === 'MEDIUM' ? 'EXERCISE CAUTION. ' : 'SAFE VERIFIED. '}
                    </span>
                    {result.recommendation}
                  </p>
                </div>

                {/* Quick Actions Footer */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={copyResults}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold border border-white/10 transition-colors cursor-pointer"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied' : 'Copy Report'}</span>
                    </button>
                  </div>

                  {result.risk_score > 30 && (
                    <button
                      onClick={() => onNavigate('report', { 
                        description: inputText, 
                        category: result.category !== "Safe / No Significant Risk" ? result.category : "Phishing" 
                      })}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-500/30 transition-colors cursor-pointer"
                    >
                      <Flag className="w-3.5 h-3.5 text-rose-400" />
                      <span>Report to Global Network</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
