import React from 'react';
import { Shield, BarChart3, Search, Globe, Flag, ShieldCheck } from 'lucide-react';
import { ActiveTab } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="sticky top-0 z-50 border-b border-white/10 backdrop-blur-xl bg-slate-950/50 px-4 sm:px-8 py-3 transition-all">
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Logo */}
        <div 
          onClick={() => setActiveTab('dashboard')}
          className="flex items-center gap-3 cursor-pointer group"
          id="nav-logo"
        >
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-extrabold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400 group-hover:from-white group-hover:to-cyan-200 transition-colors">
                AI SCAM SHIELD
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-400 border border-blue-500/20">
                v4.2
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">Proactive Threat Intelligence & Defense</p>
          </div>
        </div>

        {/* Navigation Tabs (Frosted glass container) */}
        <div className="flex items-center gap-1 sm:gap-2 bg-white/5 border border-white/10 p-1.5 rounded-2xl backdrop-blur-md" id="nav-tabs">
          <button
            id="nav-tab-dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold tracking-wide transition-all cursor-pointer ${
              activeTab === 'dashboard'
                ? 'bg-blue-600/80 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span className="uppercase">Dashboard</span>
          </button>

          <button
            id="nav-tab-analyzer"
            onClick={() => setActiveTab('analyzer')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold tracking-wide transition-all cursor-pointer ${
              activeTab === 'analyzer'
                ? 'bg-blue-600/80 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Search className="w-4 h-4" />
            <span className="uppercase">Analyzer</span>
          </button>

          <button
            id="nav-tab-url"
            onClick={() => setActiveTab('url-scanner')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold tracking-wide transition-all cursor-pointer ${
              activeTab === 'url-scanner'
                ? 'bg-blue-600/80 text-white shadow-lg shadow-blue-600/30 border border-blue-400/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span className="uppercase">URL Scanner</span>
          </button>

          <button
            id="nav-tab-report"
            onClick={() => setActiveTab('report')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold tracking-wide transition-all cursor-pointer ${
              activeTab === 'report'
                ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-lg shadow-rose-600/30 border border-rose-400/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Flag className="w-4 h-4" />
            <span className="uppercase">Report Scam</span>
          </button>
        </div>

        {/* Live System Status (from Design HTML) */}
        <div className="hidden lg:flex items-center gap-4">
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">System Status</span>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest font-semibold">Protected</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};
