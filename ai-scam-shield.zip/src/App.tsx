/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { AnalyzerView } from './components/AnalyzerView';
import { UrlScannerView } from './components/UrlScannerView';
import { ReportView } from './components/ReportView';
import { ActiveTab } from './types';
import { Shield, Lock, EyeOff, Radio } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [analyzerPrefill, setAnalyzerPrefill] = useState<string>('');
  const [reportPrefill, setReportPrefill] = useState<{
    description?: string;
    category?: string;
    sender?: string;
  }>({});

  const handleNavigate = (tab: ActiveTab, data?: any) => {
    if (tab === 'analyzer' && data?.text) {
      setAnalyzerPrefill(data.text);
    }
    if (tab === 'report' && data) {
      setReportPrefill({
        description: data.description || '',
        category: data.category || 'Phishing',
        sender: data.sender || ''
      });
    }
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col text-[#f1f5f9] bg-[#0f172a] relative overflow-hidden selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Frosted Glass Ambient Glowing Orbs */}
      <div className="fixed top-[-100px] right-[-100px] w-[400px] sm:w-[500px] h-[400px] sm:h-[500px] bg-blue-600/20 rounded-full blur-[100px] pointer-events-none -z-10" />
      <div className="fixed bottom-[-100px] left-[-100px] w-[400px] sm:w-[500px] h-[400px] sm:h-[500px] bg-cyan-600/10 rounded-full blur-[100px] pointer-events-none -z-10" />

      {/* Top Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 z-10">
        {/* Hero Section */}
        <section className="text-center mb-10 sm:mb-12 hero" id="hero-section">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider mb-4 backdrop-blur-md">
            <Radio className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
            <span>Real-Time Phishing & Social Engineering Defense</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight mb-4 bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
            Detect. Understand. Prevent.
          </h1>
          
          <p className="max-w-2xl mx-auto text-base sm:text-lg text-slate-400 font-normal leading-relaxed">
            Intelligent protection against digital scams before they become financial losses.
          </p>
        </section>

        {/* View Switcher */}
        <div className="w-full">
          {activeTab === 'dashboard' && (
            <DashboardView onNavigate={handleNavigate} />
          )}

          {activeTab === 'analyzer' && (
            <AnalyzerView 
              initialText={analyzerPrefill} 
              onNavigate={handleNavigate} 
            />
          )}

          {activeTab === 'url-scanner' && (
            <UrlScannerView onNavigate={handleNavigate} />
          )}

          {activeTab === 'report' && (
            <ReportView 
              initialData={reportPrefill} 
              onNavigate={setActiveTab} 
            />
          )}
        </div>
      </main>

      {/* Footer & Privacy Information */}
      <footer className="mt-auto border-t border-white/10 backdrop-blur-xl bg-slate-950/50 py-6 px-4 z-10">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-slate-300">AI Scam Shield Defense Protocol</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span className="flex items-center gap-1">
              <EyeOff className="w-3.5 h-3.5 text-emerald-400" />
              Zero credential retention
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-blue-400" />
              Client-safe heuristics
            </span>
          </div>

          <p className="text-[11px] text-slate-500 text-center sm:text-right">
            Crafted for rapid cybersecurity triage & proactive community defense.
          </p>
        </div>
      </footer>
    </div>
  );
}
