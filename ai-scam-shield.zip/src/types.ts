export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export interface ThreatReport {
  id: string;
  sender: string;
  category: string;
  description: string;
  severity: 'High' | 'Medium' | 'Low';
  timestamp: string;
}

export interface AnalyzeTextResponse {
  risk_score: number;
  risk_level: RiskLevel;
  category: string;
  confidence: number;
  threats: string[];
  recommendation: string;
  matched_keywords?: Record<string, string[]>;
  ai_explanation?: string | null;
  psychological_triggers?: string[];
  verification_steps?: string[];
}

export interface AnalyzeUrlResponse {
  risk_score: number;
  risk_level: RiskLevel;
  threats: string[];
}

export interface DashboardData {
  total_scans: number;
  high_risk: number;
  recent_reports: ThreatReport[];
}

export type ActiveTab = 'dashboard' | 'analyzer' | 'url-scanner' | 'report';
