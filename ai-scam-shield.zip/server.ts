import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Ensure data directory and reports.json file exist
const DATA_DIR = path.join(process.cwd(), 'data');
const REPORTS_FILE = path.join(DATA_DIR, 'reports.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(REPORTS_FILE)) {
  fs.writeFileSync(REPORTS_FILE, JSON.stringify([], null, 2), 'utf-8');
}

// In-memory counter for total scans performed in this session
let scanCounter = 1284;
let highRiskCounter = 452;

// Scam Detector Rules & Logic
interface KeywordCategoryMap {
  [key: string]: string[];
}

const KEYWORDS: KeywordCategoryMap = {
  PHISHING: ["verify", "account", "blocked", "login", "secure", "update", "suspended", "security", "kyc", "pan card", "debit card", "unauthorized", "netbanking"],
  UPI_FRAUD: ["pay", "request", "pin", "receive", "scanner", "कैशबैक", "refund", "collect", "cashback", "phonepe", "paytm", "gpay", "upi pin"],
  JOB_SCAM: ["work from home", "salary", "registration fee", "part-time", "hiring", "telegram", "daily earning", "easy task", "like and subscribe"],
  INVESTMENT: ["guaranteed", "profit", "crypto", "returns", "invest", "trading", "double", "arbitrage", "forex", "passive income"],
  URGENCY: ["immediately", "urgent", "today", "within 24 hours", "now", "hurry", "expired", "within 1 hour", "action required", "last chance"],
  REWARD: ["won", "lottery", "gift card", "reward", "prize", "congratulations", "claims", "jackpot", "lucky draw", "free voucher"]
};

const SUSPICIOUS_TLDS = [
  '.xyz', '.top', '.buzz', '.tk', '.ml', '.click', '.live', '.loan',
  '.cf', '.gq', '.cc', '.work', '.cn', '.rest', '.cam', '.country', '.gdn'
];

function analyzeTextRuleEngine(rawContent: string) {
  const text = (rawContent || '').toLowerCase();
  let risk_score = 0;
  const detected_threats: string[] = [];
  const keywordMatches: Record<string, string[]> = {};
  let category = "Safe / No Significant Risk";

  const matchesCount: Record<string, number> = {};
  for (const cat of Object.keys(KEYWORDS)) {
    matchesCount[cat] = 0;
    keywordMatches[cat] = [];
    for (const word of KEYWORDS[cat]) {
      if (text.includes(word)) {
        matchesCount[cat] += 1;
        keywordMatches[cat].push(word);
        risk_score += 15;
      }
    }
  }

  // Check 10-digit phone numbers
  if (/\b\d{10}\b/.test(text)) {
    risk_score += 5;
    detected_threats.push("Unverified 10-digit contact number detected");
  }

  // Check URLs / Domains
  if (text.includes("http") || text.includes(".com") || text.includes(".in") || text.includes(".net") || text.includes("bit.ly") || text.includes("t.me")) {
    risk_score += 20;
    detected_threats.push("Suspicious link or redirect detected");
  }

  // Specific Social Engineering Detection
  if (risk_score > 0) {
    let maxCat = Object.keys(matchesCount)[0];
    let maxCount = matchesCount[maxCat];
    for (const [cat, count] of Object.entries(matchesCount)) {
      if (count > maxCount) {
        maxCount = count;
        maxCat = cat;
      }
    }

    if (maxCount > 0) {
      category = maxCat
        .toLowerCase()
        .replace(/_/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase())
        .replace(/\bUpi\b/g, 'UPI');
    }

    if (text.includes("immediately") || text.includes("urgent") || text.includes("today") || text.includes("now") || text.includes("24 hours")) {
      if (!detected_threats.includes("Urgency/Pressure tactics detected")) {
        detected_threats.push("Urgency/Pressure tactics detected");
      }
    }
    if (["won", "lottery", "prize", "gift card", "reward", "congratulations"].some((w) => text.includes(w))) {
      if (!detected_threats.includes("Reward manipulation detected")) {
        detected_threats.push("Reward manipulation detected");
      }
    }
    if (["blocked", "kyc", "suspended", "account", "pan card", "verify"].some((w) => text.includes(w))) {
      if (!detected_threats.includes("Account/KYC fear tactics")) {
        detected_threats.push("Account/KYC fear tactics");
      }
    }
    if (["pin", "scanner", "qr", "upi"].some((w) => text.includes(w))) {
      if (!detected_threats.includes("Financial authorization credential lure (PIN/QR)")) {
        detected_threats.push("Financial authorization credential lure (PIN/QR)");
      }
    }
  }

  risk_score = Math.min(risk_score, 100);

  let risk_level: "LOW" | "MEDIUM" | "HIGH" = "LOW";
  if (risk_score > 75) {
    risk_level = "HIGH";
  } else if (risk_score > 40) {
    risk_level = "MEDIUM";
  }

  const confidence = risk_score > 0 ? Math.min(risk_score + 10, 98) : 0;

  let recommendation = "Always stay vigilant, but no immediate threat was detected.";
  if (risk_level === "HIGH") {
    recommendation = "DANGER: Do not click any links or share information. Verify via official channels only.";
  } else if (risk_level === "MEDIUM") {
    recommendation = "CAUTION: This message shows patterns typical of scams. Proceed with extreme care.";
  }

  return {
    risk_score,
    risk_level,
    category,
    confidence,
    threats: detected_threats,
    recommendation,
    matched_keywords: keywordMatches
  };
}

function analyzeUrlRuleEngine(rawUrl: string) {
  const url = (rawUrl || '').trim().toLowerCase();
  let risk_score = 0;
  const reasons: string[] = [];

  if (!url) {
    return {
      risk_score: 0,
      risk_level: "LOW",
      threats: ["No URL provided"]
    };
  }

  // TLD check
  if (SUSPICIOUS_TLDS.some((tld) => url.endsWith(tld) || url.includes(`${tld}/`) || url.includes(`${tld}?`))) {
    risk_score += 40;
    reasons.push("Suspicious top-level domain (frequently used in phishing campaigns)");
  }

  // Excessive subdomains
  const domainPart = url.replace(/https?:\/\//, '').split('/')[0].split('?')[0];
  const dotCount = (domainPart.match(/\./g) || []).length;
  if (dotCount > 3) {
    risk_score += 30;
    reasons.push("Excessive subdomains (Phishing tactic to disguise domain)");
  }

  // Insecure HTTP
  if (url.startsWith("http://")) {
    risk_score += 20;
    reasons.push("Insecure connection (HTTP without SSL/TLS encryption)");
  }

  // IP address as hostname
  if (/^https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(url) || /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(url)) {
    risk_score += 35;
    reasons.push("Direct IP address used instead of legitimate domain name");
  }

  // Suspicious brands in domain subdomain
  const targetBrands = ["sbi", "hdfc", "icici", "paypal", "netflix", "paytm", "amazon", "apple", "google", "bank"];
  for (const brand of targetBrands) {
    if (url.includes(brand) && !url.includes(`${brand}.com`) && !url.includes(`${brand}.co.in`)) {
      risk_score += 25;
      reasons.push(`Target brand '${brand}' impersonation pattern in non-standard domain`);
      break;
    }
  }

  // At symbol obfuscation
  if (url.includes("@")) {
    risk_score += 30;
    reasons.push("URL credential obfuscation syntax ('@' sign)");
  }

  risk_score = Math.min(risk_score > 0 ? risk_score + 10 : 5, 100);

  let risk_level = "LOW";
  if (risk_score > 60) {
    risk_level = "HIGH";
  } else if (risk_score > 30) {
    risk_level = "MEDIUM";
  }

  return {
    risk_score,
    risk_level,
    threats: reasons.length > 0 ? reasons : ["No immediate malicious traits detected in URL structure."]
  };
}

// Lazy-initialized Gemini AI instance
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "" || apiKey.includes("PLACEHOLDER")) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// POST /api/analyze
app.post('/api/analyze', async (req, res) => {
  try {
    const content = req.body?.content || '';
    const requestedAiDeep = req.body?.deepAi !== false;

    scanCounter += 1;
    const ruleResult = analyzeTextRuleEngine(content);

    if (ruleResult.risk_level === 'HIGH') {
      highRiskCounter += 1;
    }

    let aiExplanation: string | null = null;
    let psychologicalTriggers: string[] = [];
    let verificationChecklist: string[] = [];

    // Optional Gemini enhancement if API key is present
    const ai = getGeminiClient();
    if (ai && requestedAiDeep && content.trim().length > 10) {
      try {
        const prompt = `You are a cybersecurity expert analyzing potential scam or phishing communications.
Analyze this message:
"""${content}"""

Provide a brief, actionable intelligence breakdown:
1. Explain in 2 sentences why it is dangerous or safe.
2. List 2 key psychological pressure points or social engineering tactics (e.g., Urgency, Authority Impersonation, FOMO, False Penalty).
3. List 2 concrete verification steps the recipient should take before doing anything.

Output in JSON format with keys: "summary", "psychologicalTriggers" (array of strings), "verificationSteps" (array of strings).`;

        const timeoutPromise = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('AI inspection timeout')), 3500)
        );

        const aiPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json'
          }
        });

        const response: any = await Promise.race([aiPromise, timeoutPromise]);

        if (response.text) {
          const parsed = JSON.parse(response.text);
          aiExplanation = parsed.summary || null;
          psychologicalTriggers = parsed.psychologicalTriggers || [];
          verificationChecklist = parsed.verificationSteps || [];
        }
      } catch (err) {
        console.warn('Gemini deep inspection fallback:', err);
      }
    }

    res.json({
      ...ruleResult,
      ai_explanation: aiExplanation,
      psychological_triggers: psychologicalTriggers,
      verification_steps: verificationChecklist
    });
  } catch (error) {
    console.error('Error analyzing message:', error);
    res.status(500).json({ error: 'Failed to analyze text' });
  }
});

// POST /api/analyze-url
app.post('/api/analyze-url', (req, res) => {
  try {
    const url = req.body?.url || '';
    scanCounter += 1;
    const result = analyzeUrlRuleEngine(url);
    if (result.risk_level === 'HIGH') {
      highRiskCounter += 1;
    }
    res.json(result);
  } catch (error) {
    console.error('Error analyzing url:', error);
    res.status(500).json({ error: 'Failed to analyze URL' });
  }
});

// POST /api/report
app.post('/api/report', (req, res) => {
  try {
    const reportData = req.body || {};
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);

    let currentReports: any[] = [];
    if (fs.existsSync(REPORTS_FILE)) {
      try {
        currentReports = JSON.parse(fs.readFileSync(REPORTS_FILE, 'utf-8'));
      } catch {
        currentReports = [];
      }
    }

    const newReport = {
      id: `rep-${Date.now().toString(36)}`,
      sender: reportData.sender || 'Unknown Sender',
      category: reportData.category || 'General Scam',
      description: reportData.description || 'No description provided.',
      severity: reportData.severity || 'High',
      timestamp
    };

    currentReports.push(newReport);
    fs.writeFileSync(REPORTS_FILE, JSON.stringify(currentReports, null, 2), 'utf-8');

    res.json({ status: 'success', message: 'Report submitted successfully', report: newReport });
  } catch (error) {
    console.error('Error submitting report:', error);
    res.status(500).json({ error: 'Failed to record report' });
  }
});

// GET /api/dashboard
app.get('/api/dashboard', (req, res) => {
  try {
    let reports: any[] = [];
    if (fs.existsSync(REPORTS_FILE)) {
      try {
        reports = JSON.parse(fs.readFileSync(REPORTS_FILE, 'utf-8'));
      } catch {
        reports = [];
      }
    }

    const highSeverityCount = reports.filter((r) => r.severity === 'High').length;

    res.json({
      total_scans: scanCounter + reports.length,
      high_risk: highRiskCounter + highSeverityCount,
      recent_reports: reports.slice(-6).reverse()
    });
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    res.status(500).json({ error: 'Failed to load dashboard data' });
  }
});

// ----------------------------------------------------
// VITE MIDDLEWARE / SPA FALLBACK
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
